# -*- coding: utf8 -*-
TP_SERVER_VER = "3.3.1"
TP_ASSIST_REQUIRE_VER = "3.3.1"
